# BMI계산기

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/oiuwjxwj-the-selector/pen/01a1ae8c-5de1-7d3e-903c-ed6f66fc7745](https://codepen.io/editor/oiuwjxwj-the-selector/pen/01a1ae8c-5de1-7d3e-903c-ed6f66fc7745).

